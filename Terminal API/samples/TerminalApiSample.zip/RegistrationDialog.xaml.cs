﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Interop;

namespace TerminalApiSampleApp
{
    /// <summary>
    /// Interaction logic for RegistrationDialog.xaml
    /// </summary>
    public partial class RegistrationDialog : Window, System.Windows.Forms.IWin32Window
    {
        private bool _remoteRegistrationEnabled;
        public RegistrationDialog(bool remoteRegistrationEnabled)
        {
            InitializeComponent();
            _remoteRegistrationEnabled = remoteRegistrationEnabled;
            this.RemoteRegistrationCheckbox.Checked += new RoutedEventHandler(OnRemoteRegistrationChange);
            this.RemoteRegistrationCheckbox.Unchecked += new RoutedEventHandler(OnRemoteRegistrationChange);
            this.RemoteRegistrationCheckbox.IsEnabled = remoteRegistrationEnabled;
            this.Loaded += (sender, e) => { this.MachineNameEntry.Focus(); };
        }

        public IntPtr Handle
        {
            get { return new WindowInteropHelper(this).Handle; }
        }

        private void OnRemoteRegistrationChange(object sender, RoutedEventArgs e)
        {
            this.MachineNameEntry.IsEnabled = this.RemoteRegistrationCheckbox.IsChecked.Value;
        }

        public bool RemoteRegistration
        {
            get { return this.RemoteRegistrationCheckbox.IsChecked.Value; }
            set { this.RemoteRegistrationCheckbox.IsChecked = value && _remoteRegistrationEnabled; }
        }

        public string MachineName
        {
            get { return this.MachineNameEntry.Text; }
            set { this.MachineNameEntry.Text = value; }
        }

        private void OnRegisterClick(object sender, RoutedEventArgs e)
        {
            if (RemoteRegistration && String.IsNullOrEmpty(MachineName))
            {
                MessageBoxEx.Show(this, "Machine name is required for remote API registration");
                return;
            }
            this.DialogResult = true;
            this.Close();
        }
    }
}
