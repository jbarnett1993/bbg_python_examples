﻿Bloomberg Terminal API Sample Application

In order to build and run this sample application from source you will need to give the application 
a strong name by doing the following:
	Right click on the project and select "properties" from context menu. 
	Select the "Signing" tab on left. 
	Check the "Sign the assembly" check box.
	Select "<Browse...>" from drop down and browse to location of your existing strong name key file 
		or select "<New..>" from drop down to create a new strong name key file.
Once your application is built with a strong name you will have to register the public key token with Bloomberg.
To get the public key token for your application run the following command: 
	"%ProgramFiles%\Microsoft SDKs\Windows\v7.0A\bin\sn.exe" -T <assemblyPath>
	Or if you are running on a 64 bit machine:
	"%ProgramFiles(x86)%\Microsoft SDKs\Windows\v7.0A\bin\sn.exe" -T <assemblyPath>