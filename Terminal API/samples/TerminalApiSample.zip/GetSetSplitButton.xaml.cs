﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TerminalApiSampleApp
{
    /// <summary>
    /// Interaction logic for GetSetSplitButton.xaml
    /// </summary>
    public partial class GetSetSplitButton : UserControl
    {
        public static readonly DependencyProperty IsSetProperty = DependencyProperty.Register(
            "IsSet", typeof(Boolean), typeof(GetSetSplitButton), new FrameworkPropertyMetadata(true,
                FrameworkPropertyMetadataOptions.AffectsRender,
                new PropertyChangedCallback(OnIsSetChanged)
            ));

        public event EventHandler GetSetClick;
        public event EventHandler GetSetChange;

        public Boolean IsSet
        {
            get { return (Boolean)this.GetValue(IsSetProperty); }
            set {
                var origVal = this.IsSet;
                this.SetValue(IsSetProperty, value);
                if (origVal != this.IsSet && GetSetChange != null)
                    GetSetChange(this, EventArgs.Empty);
            }
        }

        public GetSetSplitButton()
        {
            InitializeComponent();
            this.button.Content = "Set";
            this.button.Click += new RoutedEventHandler(OnButtonClick);
            this.combobox.DropDownOpened += new EventHandler(OnComboboxOpening);
            this.combobox.SelectionChanged += new SelectionChangedEventHandler(OnComboboxSelectionChanged);
            this.IsEnabledChanged += new DependencyPropertyChangedEventHandler(OnIsEnabledChanged);
        }

        private Brush _origBackground = null;
        public void SetButtonBackground(Brush bg)
        {
            if (_origBackground == null)
                _origBackground = this.button.Background;
            this.button.Background = (bg == null ? _origBackground : bg);
        }

        private void OnIsEnabledChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            this.button.IsEnabled = this.IsEnabled;
            this.combobox.IsEnabled = this.IsEnabled;
        }

        private void OnButtonClick(object sender, RoutedEventArgs e)
        {
            if (this.GetSetClick != null)
                this.GetSetClick(this, EventArgs.Empty);
        }

        private static void OnIsSetChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            var ctrl = (GetSetSplitButton)sender;
            ctrl.button.Content = ctrl.IsSet ? "Set" : "Get";
        }

        private void OnComboboxSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var s = this.combobox.SelectedItem as string;
            if (!String.IsNullOrEmpty(s)) {
                this.IsSet = s.Contains("Set");
                if (GetSetChange != null)
                    GetSetChange(this, EventArgs.Empty);
            }
        }

        private void OnComboboxOpening(object sender, EventArgs e)
        {
            this.combobox.Items.Clear();
            this.combobox.Items.Add(IsSet ? "   Get   " : "   Set   ");
        }
    }
}
