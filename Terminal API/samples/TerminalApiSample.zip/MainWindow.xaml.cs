﻿using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows;
using System.Windows.Interop;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Bloomberglp.Component.Wpf.UI;
using Bloomberglp.TerminalApiEx;
using Bloomberglp.TerminalApiEx.Charts;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using System.ComponentModel;

namespace TerminalApiSampleApp
{
    public partial class MainWindow : Window, System.Windows.Forms.IWin32Window
    {
        private bool _isRegistered;
        private bool _remoteRegistration;
        private string _remoteMachine;
        private readonly ObservableCollection<PropertyItem> _creationProperties = new ObservableCollection<PropertyItem>();
        private readonly ObservableCollection<ChartLineViewModel> _lines = new ObservableCollection<ChartLineViewModel>();

        private class PropertyItem
        {
            public string Name { get; set; }
            public object Value { get; set; }
            public Type Type { get; set; }
        }

        private class ComponentInfo
        {
            public string Name { get; set; }
            public string DisplayName { get; set; }
            public List<PropertyItem> DefaultProperties { get; set; }
            public override string ToString()
            {
                return DisplayName;
            }
        }

        private class ChartLineViewModel : INotifyPropertyChanged
        {
            private readonly ChartLine _chartLine;
            public event PropertyChangedEventHandler PropertyChanged;
            public ChartLineViewModel() {
                _chartLine = new ChartLine();
            }
            public ChartLineViewModel(ChartLine chartLine) {
                _chartLine = chartLine;
            }
            public ChartLine ChartLine { 
                get { return _chartLine; } 
            }
            public string Currency {
                get { return _chartLine.Currency; }
                set { _chartLine.Currency = value; }
            }
            public string DataField {
                get { return _chartLine.DataField; }
                set { _chartLine.DataField = value; }
            }
            public string Id {
                get { return _chartLine.Id; }
                set { _chartLine.Id = value; }
            }
            public string PCS {
                get { return _chartLine.PCS; }
                set { _chartLine.PCS = value; }
            }
            public string Security {
                get { return _chartLine.Security; }
                set { _chartLine.Security = value; }
            }
            private bool _isReadonly;
            public bool IsReadOnly
            {
                get { return _isReadonly; }
                set { 
                    _isReadonly = value;
                    if (PropertyChanged != null)
                        PropertyChanged(this, new PropertyChangedEventArgs("IsReadOnly"));
                }
            }
        }

        public MainWindow()
        {
            InitializeComponent();
            InitializeComponentList();
            BlpApi.Disconnected += OnBlpApiDisconnected;
            BlpApi.Timeout = 10000;
        }

        public IntPtr Handle
        {
            get { return new WindowInteropHelper(this).Handle; }
        }

        private void OnBlpApiDisconnected(object sender, EventArgs e)
        {
            _isRegistered = false;
            Dispatcher.BeginInvoke((Action)delegate
            {
                EventsSubscribeButton.IsEnabled = true;
                EventsUnsubscribeButton.IsEnabled = false;
                EventsLog.Text = null;
                SetGroups(null);
                GroupContextLabel.Text = "";
                GetGroupContextButton.IsEnabled = false;
                GroupContextInput.IsEnabled = false;
                GroupContextCookie.IsEnabled = false;
                SetGroupContextButton.IsEnabled = false;
                EmbedRegion.Content = null;
                EmbedRegion.Visibility = Visibility.Visible;
                ClearProperties();
                EnableComponentCreation(true);
                EnableChartProperties(false);
                EnableGenericComponentProperties(false);
                StatusLabel.Text = null;
                ConnectionLabel.Text = "Status: Not Connected";
                MessageBoxEx.Show(this, "API Disconnected");
            });
        }

        private void InitializeComponentList()
        {
            ComponentList.SelectionChanged += delegate
            {
                _creationProperties.Clear();
                var component = ComponentList.SelectedItem as ComponentInfo;
                if (component != null && component.DefaultProperties != null)
                {
                    foreach (var item in component.DefaultProperties)
                        _creationProperties.Add(new PropertyItem { Name = item.Name, Value = item.Value });
                }
                else
                {
                    _creationProperties.Add(new PropertyItem());
                    _creationProperties.Add(new PropertyItem());
                }
                if (component.Name.Equals("BCHART"))
                {
                    ChartProperties.Visibility = Visibility.Visible;
                    GenericProperties.Visibility = Visibility.Collapsed;
                }
                else
                {
                    ChartProperties.Visibility = Visibility.Collapsed;
                    GenericProperties.Visibility = Visibility.Visible;
                }
            };
            ComponentList.ItemsSource = GetComponentInfo();
            CreationPropertiesList.ItemsSource = _creationProperties;
            CreationPropertiesList.SelectionChanged += delegate
            {
                RemovePropertyButton.IsEnabled = CreationPropertiesList.SelectedItem is PropertyItem;
            };
            RemovePropertyButton.Click += delegate
            {
                _creationProperties.RemoveAt(CreationPropertiesList.SelectedIndex);
            };
            AddPropertyButton.Click += delegate
            {
                var newItem = new PropertyItem();
                _creationProperties.Add(newItem);
            };
            Periodicity.ItemsSource = Enum.GetValues(typeof(ChartPeriodicity));
            Lines.ItemsSource = _lines;
            Lines.SelectionChanged += delegate
            {
                RemoveLineButton.IsEnabled = (Lines.SelectedItem is ChartLineViewModel && LinesGetSet.IsEnabled && LinesGetSet.IsSet);
            };
            RemoveLineButton.Click += delegate
            {
                if (Lines.SelectedIndex > -1)
                {
                    _lines.RemoveAt(Lines.SelectedIndex);
                    ChartPendingChanges(true);
                }
            };
            AddLineButton.Click += delegate
            {
                var newItem = new ChartLineViewModel() { IsReadOnly = false, DataField = "PR005" };
                _lines.Add(newItem);
                PropertyScrollViewer.ScrollToEnd();
                Dispatcher.BeginInvoke(DispatcherPriority.Background, (Action)delegate
                {
                    var container = Lines.ItemContainerGenerator.ContainerFromItem(newItem) as ListViewItem;
                    FocusSecurityInput(container);
                });
                ChartPendingChanges(true);
            };
            ComponentList.SelectedIndex = 0;
        }

        private void FocusSecurityInput(DependencyObject targetElement)
        {
            var count = targetElement != null ? VisualTreeHelper.GetChildrenCount(targetElement) : 0;
            if (count == 0) return;
            for (int i = 0; i < count; i++)
            {
                var child = VisualTreeHelper.GetChild(targetElement, i);
                if (child is TextBox)
                {
                    var targetItem = (TextBox)child;
                    if (targetItem.Name == "SecurityInput")
                    {
                        targetItem.Focus();
                        return;
                    }
                }
                else
                {
                    FocusSecurityInput(child);
                }
            }
        }

        private void ChartPendingChanges(bool hasChanges)
        {
            if (hasChanges)
            {
                LinesLabel.Text = "Press 'Set' Button To Update Chart";
                LinesLabel.Foreground = Brushes.Red;
                LinesGetSet.SetButtonBackground(Brushes.Red);
            }
            else
            {
                LinesLabel.Text = "Lines";
                LinesLabel.Foreground = Brushes.Gray;
                LinesGetSet.SetButtonBackground(null);
            }
        }

        private static IEnumerable<ComponentInfo> GetComponentInfo()
        {
            var components = new List<ComponentInfo>();
            using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("TerminalApiSampleApp.component_info.csv"))
            using (var reader = new StreamReader(stream))
            {
                string line;
                while ((line = reader.ReadLine()) != null) {
                    var parts = line.Split(',');
                    if (parts.Length < 2)
                        continue;
                    var item = new ComponentInfo { Name = parts[0], DisplayName = parts[1] };
                    if (parts.Length > 2) {
                        item.DefaultProperties = new List<PropertyItem>();
                        for (var i = 2; i < parts.Length; i++) {
                            int colonIndex = parts[i].IndexOf(":");
                            if (colonIndex != -1)
                            {
                                item.DefaultProperties.Add(new PropertyItem { Name = parts[i].Substring(0, colonIndex), Value = parts[i].Substring(colonIndex + 1) });
                            }
                        }
                    }
                    components.Add(item);
                }
            }
            return components;
        }

        private void DoRegistration(Action registrationCompleteCallback)
        {
            Action internalComplete = delegate
            {
                _isRegistered = true;
                ConnectionLabel.Text = "Status: Connected";
                RemoteMachineLabel.Text = _remoteRegistration ? "Remote Machine: " + _remoteMachine : null;
                if (registrationCompleteCallback != null)
                    registrationCompleteCallback();
            };
            ConnectionLabel.Text = "Status: Connecting...";
            if (_remoteRegistration)
            {
                BlpApi.BeginRegisterRemote(_remoteMachine, (AsyncCallback)delegate(IAsyncResult ar)
                {
                    Dispatcher.BeginInvoke((Action)delegate
                    {
                        try {
                            BlpApi.EndRegisterRemote(ar);
                            internalComplete();
                        } catch (Exception ex) {
                            ConnectionLabel.Text = (ex.Message != null && ex.Message.Contains("Already Registered") ? "Status: Connected" : "Status: Not Connected");
                            if (ex.Message.IndexOf("public key", StringComparison.OrdinalIgnoreCase) >= 0 || ex.Message.IndexOf("strong name", StringComparison.OrdinalIgnoreCase) >= 0)
                                MessageBoxEx.Show(this, "Application assembly must have a strong name and assembly public key token has to be registered with Bloomberg in order for application to use the Bloomberg Terminal API. For more information please refer to the Terminal API documentation.", "API Not Enabled", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);
                            else
                                MessageBoxEx.Show(this, ex.Message, "Connection Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                        }
                    });
                }, null);
            }
            else
            {
                BlpApi.BeginRegister((AsyncCallback)delegate(IAsyncResult ar)
                {
                    Dispatcher.BeginInvoke((Action)delegate {
                        try {
                            BlpApi.EndRegister(ar);
                            internalComplete();
                        } catch (Exception ex) {
                            ConnectionLabel.Text = (ex.Message != null && ex.Message.Contains("Already Registered") ? "Status: Connected" : "Status: Not Connected");
                            if (ex.Message.IndexOf("public key", StringComparison.OrdinalIgnoreCase) >= 0 || ex.Message.IndexOf("strong name", StringComparison.OrdinalIgnoreCase) >= 0)
                                MessageBoxEx.Show(this, "Application assembly must have a strong name and assembly public key token has to be registered with Bloomberg in order for application to use the Bloomberg Terminal API. For more information please refer to the Terminal API documentation.", "API Not Enabled", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);
                            else
                                MessageBoxEx.Show(this, ex.Message, "Connection Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                        }
                    });
                }, null);
            }
        }

        private void ExecuteApiCall(Action operation)
        {
            Action DoOperation = delegate {
                StatusLabel.Text = "Making API Call...";
                try {
                    operation();
                } catch (Exception e) {
                    MessageBoxEx.Show(this, e.Message, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                } finally {
                    StatusLabel.Text = null;
                }
            };
            if (_isRegistered)
                DoOperation();
            else
                DoRegistration(() => { DoOperation(); });
        }

        private void OnRunFunctionButtonClick(object sender, EventArgs args)
        {
            ExecuteApiCall(delegate
            {
                var securities = new List<string>();
                if (!String.IsNullOrEmpty(Sec1Input.Text.Trim()))
                    securities.Add(Sec1Input.Text.Trim());
                if (!String.IsNullOrEmpty(Sec2Input.Text.Trim()))
                    securities.Add(Sec2Input.Text.Trim());
                var properties = new List<BlpProperty>();
                BlpTerminal.BeginRunFunction(MnemonicInput.Text, PanelInput.Text, securities, properties, TailsInput.Text, delegate(IAsyncResult ar)
                {
                    Dispatcher.BeginInvoke((Action)delegate {
                        try {
                            BlpTerminal.EndRunFunction(ar);
                        } catch (Exception e) {
                            MessageBoxEx.Show(this, e.Message, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                        }
                    });
                }, null);
            });
        }

        private IList<BlpProperty> GetCreationProperties()
        {
            var properties = new List<BlpProperty>();
            try {
                foreach (var item in _creationProperties) {
                    if (String.IsNullOrEmpty(item.Name) || item.Value == null || item.Value as string == "")
                        continue;
                    if (item.Type == typeof(Int32))
                        properties.Add(new BlpProperty(item.Name, Convert.ToInt32(item.Value)));
                    else if (item.Type == typeof(Double))
                        properties.Add(new BlpProperty(item.Name, Convert.ToDouble(item.Value)));
                    else if (item.Type == typeof(Boolean))
                        properties.Add(new BlpProperty(item.Name, Convert.ToBoolean(item.Value)));
                    else
                        properties.Add(new BlpProperty(item.Name, item.Value));
                }
            } catch (Exception e) {
                MessageBoxEx.Show(this, e.Message, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
            }
            return properties;
        }

        private void OnCreateDestroyComponent(object sender, EventArgs args)
        {
            if (((Button)sender).Content as string == "Create")
                CreateComponent();
            else
                DestroyComponent();
        }

        private void EnableComponentCreation(bool enable)
        {
            CreateDestroyComponentButton.Content = enable ? "Create" : "Destroy";
            ComponentList.IsEnabled = enable;
            CreationPropertiesList.IsEnabled = enable;
            AddPropertyButton.IsEnabled = enable;
            RemovePropertyButton.IsEnabled = enable;
            if (enable)
                ComponentLabel.Text = "Select Component\n To Embed Above";
        }

        private void EnableGenericComponentProperties(bool enable)
        {
            PropertyNameGetterInput.IsEnabled = enable;
            PropertyValueGetterDisplay.IsEnabled = enable;
            GetPropertyButton.IsEnabled = enable;
            PropertyNameSetterInput.IsEnabled = enable;
            PropertyValueSetterInput.IsEnabled = enable;
            SetPropertyButton.IsEnabled = enable;
        }

        private void EnableChartProperties(bool enable)
        {
            Shortcut.IsEnabled = enable;
            ShortcutGetSet.IsEnabled = enable;
            PrimarySecurity.IsEnabled = enable;
            PrimarySecurityGetSet.IsEnabled = enable;
            StartDate.IsEnabled = enable;
            StartDateGetSet.IsEnabled = enable;
            EndDate.IsEnabled = enable;
            EndDateGetSet.IsEnabled = enable;
            Periodicity.IsEnabled = enable;
            PeriodicityGetSet.IsEnabled = enable;
            Lines.IsEnabled = enable;
            LinesGetSet.IsEnabled = enable;
            AddLineButton.IsEnabled = enable;
            RemoveLineButton.IsEnabled = enable;
        }

        private void ClearProperties()
        {
            PropertyNameGetterInput.Text = null;
            PropertyValueGetterDisplay.Text = null;
            PropertyNameSetterInput.Text = null;
            PropertyValueSetterInput.Text = null;
            Shortcut.Text = null;
            PrimarySecurity.Text = null;
            StartDate.Text = null;
            EndDate.Text = null;
            Periodicity.SelectedIndex = -1;
            _lines.Clear();
            ChartPendingChanges(false);
        }

        private void SetGroups(IList<BlpGroup> groupList)
        {
            GroupList.ItemsSource = groupList;
            GetContextGroupSelector.Items.Clear();
            GetContextGroupSelector.Items.Add("*** Select Group ***");
            GetContextGroupSelector.SelectedIndex = 0;
            SetContextGroupSelector.Items.Clear();
            SetContextGroupSelector.Items.Add("*** Select Group ***");
            SetContextGroupSelector.SelectedIndex = 0;
            GetContextGroupSelector.IsEnabled = groupList != null && groupList.Count > 0;
            SetContextGroupSelector.IsEnabled = groupList != null && groupList.Count > 0;
            if (groupList != null)
            {
                foreach (var item in groupList)
                {
                    GetContextGroupSelector.Items.Add(item);
                    SetContextGroupSelector.Items.Add(item);
                }
            }
        }

        private void CreateComponent()
        {
            var cinfo = ComponentList.SelectedItem as ComponentInfo;
            var componentName = cinfo != null ? cinfo.Name : null;
            if (String.IsNullOrEmpty(componentName))
            {
                MessageBoxEx.Show(this, "Please select a component from the list.");
                return;
            }
            Action createComponent = delegate
            {
                ComponentLabel.Text = "Creating Component...";
                StatusLabel.Text = "Creating Component...";
                BlpTerminal.BeginCreateComponent(componentName, GetCreationProperties(), delegate(IAsyncResult ar)
                {
                    Dispatcher.BeginInvoke((Action)delegate {
                        try {
                            var control = new BlpControl();
                            control.Initialize(BlpTerminal.EndCreateComponent(ar));
                            EmbedRegion.Content = control;
                            EmbedRegion.Visibility = Visibility.Visible;
                            EnableComponentCreation(false);
                            var comp = control != null ? control.Component : null;
                            if (comp != null && comp is BlpChartComponent)
                            {
                                EnableChartProperties(true);
                                GetAllChartProperies();
                            }
                            else
                            {
                                EnableGenericComponentProperties(true);
                            }
                        } catch (Exception e) {
                            MessageBoxEx.Show(this, e.Message, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                        } finally {
                            StatusLabel.Text = null;
                        }
                    });
                }, null);
            };
            var ctrl = EmbedRegion.Content as BlpControl;
            var component = ctrl != null ? ctrl.Component : null;
            if (_isRegistered && component != null)
                DisposeComponent(component, () => ExecuteApiCall(createComponent));
            else
                ExecuteApiCall(createComponent);
        }

        private void DestroyComponent()
        {
            var ctrl = EmbedRegion.Content as BlpControl;
            var component = (BlpComponent)(ctrl != null ? ctrl.Component : null);
            DisposeComponent(component, delegate
            {
                EmbedRegion.Content = null;
                EmbedRegion.Visibility = Visibility.Collapsed;
                ClearProperties();
                EnableComponentCreation(true);
                EnableChartProperties(false);
                EnableGenericComponentProperties(false);
                StatusLabel.Text = null;
            });
        }

        private void OnGetPropertyButtonClick(object sender, EventArgs args)
        {
            var ctrl = EmbedRegion.Content as BlpControl;
            var component = ctrl != null ? ctrl.Component : null;
            if (component == null)
                return;
            var propName = PropertyNameGetterInput.Text;
            if (String.IsNullOrEmpty(propName))
            {
                MessageBoxEx.Show(this, "Please enter a property name.");
                return;
            }
            PropertyValueGetterDisplay.Text = null;
            var props = new List<string>() { propName };
            component.BeginGetProperties(props, (AsyncCallback)delegate(IAsyncResult ar)
            {
                Dispatcher.BeginInvoke((Action)delegate {
                    try {
                        var list = component.EndGetProperties(ar);
                        PropertyValueGetterDisplay.Text = list.Count > 0 ? Convert.ToString(list[0].Value) : null;
                    } catch (Exception e) {
                        MessageBoxEx.Show(this, e.Message, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    }
                });
            }, null);
        }

        private void OnSetPropertyButtonClick(object sender, EventArgs args)
        {
            var ctrl = EmbedRegion.Content as BlpControl;
            var component = ctrl != null ? ctrl.Component : null;
            if (component == null)
                return;
            var propName = PropertyNameSetterInput.Text;
            if (String.IsNullOrEmpty(propName))
            {
                MessageBoxEx.Show(this, "Please enter a property name.");
                return;
            }
            var propValue = PropertyValueSetterInput.Text;
            if (String.IsNullOrEmpty(propValue))
            {
                MessageBoxEx.Show(this, "Please enter a property value.");
                return;
            }
            var props = new List<BlpProperty>() { new BlpProperty(propName, propValue) };
            component.BeginSetProperties(props, (AsyncCallback)delegate(IAsyncResult ar)
            {
                Dispatcher.BeginInvoke((Action)delegate {
                    try {
                        component.EndSetProperties(ar);
                    } catch (Exception e) {
                        MessageBoxEx.Show(this, e.Message, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    }
                });
                return;
            }, null);
        }

        private void DisposeComponent(BlpComponent component, Action callback = null)
        {
            if (component == null)
                return;
            component.BeginDispose((AsyncCallback)delegate(IAsyncResult ar) {
                Dispatcher.BeginInvoke((Action)delegate {
                    try {
                        component.EndDispose(ar);
                        if (callback != null)
                            callback();
                    } catch (Exception e) {
                        MessageBoxEx.Show(this, e.Message, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    }
                });
            }, null);
        }

        private void OnUpdateGroupsButtonClick(object sender, EventArgs args)
        {
            ExecuteApiCall(delegate
            {
                BlpTerminal.BeginGetAllGroups((AsyncCallback)delegate(IAsyncResult ar)
                {
                    Dispatcher.BeginInvoke((Action)delegate {
                        try {
                            var groupList = BlpTerminal.EndGetAllGroups(ar);
                            SetGroups(groupList);
                            if (groupList.Count < 1)
                                MessageBoxEx.Show(this, "No Groups Configured.\r\nTo configure groups run BLP<GO> (Launchpad) and\r\nopen Group Manager.\r\nCreat a new group.\r\nSelect one or more components to add to the group.", "No Groups Configured", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information);
                        } catch (Exception ex) {
                            MessageBoxEx.Show(this, ex.Message, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                        }
                    });
                }, null);
            });
        }

        private void OnEventsSubscribeButtonClick(object sender, EventArgs args)
        {
            BlpTerminal.GroupEvent -= OnGroupEventHandler;
            BlpTerminal.GroupEvent += OnGroupEventHandler;
            EventsSubscribeButton.IsEnabled = false;
            EventsUnsubscribeButton.IsEnabled = true;
            EventsLog.Text += "*** Subscribed to Group Events ***\r\n";
            EventsLog.ScrollToEnd();
        }

        private void OnEventsUnsubscribeButtonClick(object sender, EventArgs args)
        {
            BlpTerminal.GroupEvent -= OnGroupEventHandler;
            EventsSubscribeButton.IsEnabled = true;
            EventsUnsubscribeButton.IsEnabled = false;
            EventsLog.Text += "*** Unsubscribed to Group Events ***\r\n";
            EventsLog.ScrollToEnd();
        }

        private void OnGroupEventHandler(object s, BlpGroupEventArgs e)
        {
            var changeEventArgs = e as BlpGroupContextChangedEventArgs;
            if (changeEventArgs == null)
                return;
            Dispatcher.BeginInvoke((Action)delegate {
                var selectedGroup = GroupList.SelectedItem as BlpGroup;
                foreach (var group in changeEventArgs.Groups) {
                    if (selectedGroup != null && selectedGroup.Name == group.Name)
                        GroupContextLabel.Text = group.Value;
                    EventsLog.Text += (group.Name + " context changed to '" + group.Value + "', external=" + changeEventArgs.ExternalSource);
                    if (!String.IsNullOrEmpty(changeEventArgs.Cookie))
                        EventsLog.Text += (", cookie=" + changeEventArgs.Cookie);
                    EventsLog.Text += "\r\n";
                    EventsLog.ScrollToEnd();
                }
            });
        }

        private void OnGetGroupContextButtonClick(object sender, EventArgs args)
        {
            var group = GetContextGroupSelector.SelectedItem as BlpGroup;
            if (group == null)
            {
                MessageBoxEx.Show(this, "Please select a group from the list.");
                return;
            }
            GroupContextLabel.Text = "";
            ExecuteApiCall(delegate
            {
                BlpTerminal.BeginGetGroupContext(group.Name, (AsyncCallback)delegate(IAsyncResult ar)
                {
                    Dispatcher.BeginInvoke((Action)delegate {
                        try {
                            var g = BlpTerminal.EndGetGroupContext(ar);
                            GroupContextLabel.Text = g.Value;
                        } catch (Exception e) {
                            MessageBoxEx.Show(this, e.Message, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                        }
                    });
                }, null);
            });
        }

        private void OnSetGroupContextButtonClick(object sender, EventArgs args)
        {
            var group = SetContextGroupSelector.SelectedItem as BlpGroup;
            if (group == null)
            {
                MessageBoxEx.Show(this, "Please select a group from the list.");
                return;
            }
            if (string.IsNullOrEmpty(GroupContextInput.Text))
            {
                MessageBoxEx.Show(this, "Please enter a value for group context.");
                return;
            }
            ExecuteApiCall(delegate
            {
                GroupContextLabel.Text = "";
                var cookie = GroupContextCookie.Text.Trim();
                BlpTerminal.BeginSetGroupContext(group.Name, GroupContextInput.Text, cookie.Length > 0 ? cookie : null, (AsyncCallback)delegate(IAsyncResult ar)
                {
                    Dispatcher.BeginInvoke((Action)delegate {
                        try {
                            BlpTerminal.EndSetGroupContext(ar);
                        } catch (Exception e) {
                            MessageBoxEx.Show(this, e.Message, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                        }
                    });
                }, null);
            });
        }

        private void OnGroupListSelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            var itemIsSelected = GroupList.SelectedItem is BlpGroup;
            GetGroupContextButton.IsEnabled = itemIsSelected;
            GroupContextInput.IsEnabled = itemIsSelected;
            GroupContextCookie.IsEnabled = itemIsSelected;
            SetGroupContextButton.IsEnabled = itemIsSelected;
            GetContextGroupSelector.SelectedIndex = itemIsSelected ? GroupList.SelectedIndex + 1 : 0;
            SetContextGroupSelector.SelectedIndex = itemIsSelected ? GroupList.SelectedIndex + 1 : 0;
            GroupContextLabel.Text = "";
        }

        private void OnShowRegistrationDialog(object sender, RoutedEventArgs e)
        {
            var dlg = new RegistrationDialog(!_isRegistered) { 
                Owner = this, 
                RemoteRegistration = _remoteRegistration, 
                MachineName = _remoteMachine 
            };
            if (dlg.ShowDialog().GetValueOrDefault(false))
            {
                _remoteRegistration = dlg.RemoteRegistration;
                _remoteMachine = dlg.MachineName;
                DoRegistration(() => {
                    MessageBoxEx.Show(this, "Registration Complete", "Success", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Asterisk);
                });
            }
        }

        private void OnContextGroupSelectorChange(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            var cbox = (ComboBox)sender;
            if (cbox == GetContextGroupSelector)
            {
                if (GetGroupContextButton != null)
                    GetGroupContextButton.IsEnabled = cbox.SelectedIndex > 0;
                if (GroupContextLabel != null)
                    GroupContextLabel.Text = "";
            }
            else
            {
                if (SetGroupContextButton != null)
                    SetGroupContextButton.IsEnabled = cbox.SelectedIndex > 0;
                if (GroupContextInput != null)
                    GroupContextInput.IsEnabled = cbox.SelectedIndex > 0;
                if (GroupContextCookie != null)
                    GroupContextCookie.IsEnabled = cbox.SelectedIndex > 0;
            }
        }

        private T GetListViewItem<T>(ListView listView, DependencyObject ctrl) where T : class
        {
            while ((ctrl != null) && !(ctrl is ListViewItem))
                ctrl = VisualTreeHelper.GetParent(ctrl);
            return ctrl != null ? listView.ItemContainerGenerator.ItemFromContainer(ctrl) as T : null;
        }

        private void OnFocusCreationParameter(object sender, RoutedEventArgs e)
        {
            var tbox = (TextBox)sender;
            var item = GetListViewItem<PropertyItem>(CreationPropertiesList, tbox);
            if (item != null)
                CreationPropertiesList.SelectedItem = item;
        }

        private BlpChartComponent GetChartComponent()
        {
            var ctrl = EmbedRegion.Content as BlpControl;
            var component = ctrl != null ? ctrl.Component : null;
            return component as BlpChartComponent;
        }

        private void OnShortcutGetSetChange(object sender, EventArgs e)
        {
            if (!ShortcutGetSet.IsSet)
                Shortcut.Text = "";
            Shortcut.IsReadOnly = !ShortcutGetSet.IsSet;
        }

        private void OnShortcutGetSetClick(object sender, EventArgs e)
        {
            var chartComponent = GetChartComponent();
            if (chartComponent == null) return;
            if (ShortcutGetSet.IsSet) {
                chartComponent.BeginSetShortcut(Shortcut.Text, (AsyncCallback)delegate(IAsyncResult ar)
                {
                    Dispatcher.BeginInvoke((Action)delegate {
                        try {
                            chartComponent.EndSetShortcut(ar);
                        } catch (Exception ex) {
                            MessageBoxEx.Show(this, ex.Message, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                        }
                    });
                }, null);
            } else {
                chartComponent.BeginGetShortcut((AsyncCallback)delegate(IAsyncResult ar)
                {
                    Dispatcher.BeginInvoke((Action)delegate {
                        try {
                            Shortcut.Text = chartComponent.EndGetShortcut(ar);
                            ShortcutGetSet.IsSet = true;
                        } catch (Exception ex) {
                            MessageBoxEx.Show(this, ex.Message, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                        }
                    });
                }, null);
            }
        }

        private void OnPrimarySecurityGetSetChange(object sender, EventArgs e)
        {
            if (!PrimarySecurityGetSet.IsSet)
                PrimarySecurity.Text = "";
            PrimarySecurity.IsReadOnly = !PrimarySecurityGetSet.IsSet;
        }

        private void OnPrimarySecurityGetSetClick(object sender, EventArgs e)
        {
            var chartComponent = GetChartComponent();
            if (chartComponent == null) return;
            if (PrimarySecurityGetSet.IsSet) {
                chartComponent.BeginSetPrimarySecurity(PrimarySecurity.Text, (AsyncCallback)delegate(IAsyncResult ar)
                {
                    Dispatcher.BeginInvoke((Action)delegate {
                        try {
                            chartComponent.EndSetPrimarySecurity(ar);
                        } catch (Exception ex) {
                            MessageBoxEx.Show(this, ex.Message, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                        }
                    });
                }, null);
            } else {
                UpdatePrimarySecurity();
            }
        }

        private void UpdatePrimarySecurity()
        {
            var chartComponent = GetChartComponent();
            if (chartComponent == null) return;
            chartComponent.BeginGetPrimarySecurity((AsyncCallback)delegate(IAsyncResult ar)
            {
                Dispatcher.BeginInvoke((Action)delegate {
                    try {
                        PrimarySecurity.Text = chartComponent.EndGetPrimarySecurity(ar);
                        PrimarySecurityGetSet.IsSet = true;
                        UpdateLines();
                    } catch (Exception ex) {
                        MessageBoxEx.Show(this, ex.Message, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    }
                });
            }, null);
        }

        private void OnStartDateGetSetChange(object sender, EventArgs e)
        {
            if (!StartDateGetSet.IsSet)
                StartDate.Text = "";
            StartDate.IsEnabled = StartDateGetSet.IsSet;
        }

        private void OnStartDateGetSetClick(object sender, EventArgs e)
        {
            var chartComponent = GetChartComponent();
            if (chartComponent == null) return;
            if (StartDateGetSet.IsSet) {
                if (!StartDate.SelectedDate.HasValue) {
                    MessageBoxEx.Show(this, "Please select a valid date.");
                    return;
                }
                chartComponent.BeginSetStartDate(StartDate.SelectedDate.Value.ToUniversalTime(), (AsyncCallback)delegate(IAsyncResult ar)
                {
                    Dispatcher.BeginInvoke((Action)delegate {
                        try {
                            chartComponent.EndSetStartDate(ar);
                        } catch (Exception ex) {
                            MessageBoxEx.Show(this, ex.Message, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                        }
                    });
                }, null);
            } else {
                chartComponent.BeginGetStartDate((AsyncCallback)delegate(IAsyncResult ar)
                {
                    Dispatcher.BeginInvoke((Action)delegate {
                        try {
                            StartDate.SelectedDate = chartComponent.EndGetStartDate(ar).ToLocalTime();
                            StartDateGetSet.IsSet = true;
                        } catch (Exception ex) {
                            MessageBoxEx.Show(this, ex.Message, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                        }
                    });
                }, null);
            }
        }

        private void OnEndDateGetSetChange(object sender, EventArgs e)
        {
            if (!EndDateGetSet.IsSet)
                EndDate.Text = "";
            EndDate.IsEnabled = EndDateGetSet.IsSet;
        }

        private void OnEndDateGetSetClick(object sender, EventArgs e)
        {
            var chartComponent = GetChartComponent();
            if (chartComponent == null) return;
            if (EndDateGetSet.IsSet) {
                if (!EndDate.SelectedDate.HasValue) {
                    MessageBoxEx.Show(this, "Please select a valid date.");
                    return;
                }
                chartComponent.BeginSetEndDate(EndDate.SelectedDate.Value.ToUniversalTime(), (AsyncCallback)delegate(IAsyncResult ar)
                {
                    Dispatcher.BeginInvoke((Action)delegate {
                        try {
                            chartComponent.EndSetEndDate(ar);
                        } catch (Exception ex) {
                            MessageBoxEx.Show(this, ex.Message, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                        }
                    });
                }, null);
            } else {
                chartComponent.BeginGetEndDate((AsyncCallback)delegate(IAsyncResult ar)
                {
                    Dispatcher.BeginInvoke((Action)delegate {
                        try {
                            EndDate.SelectedDate = chartComponent.EndGetEndDate(ar).ToLocalTime();
                            EndDateGetSet.IsSet = true;
                        } catch (Exception ex) {
                            MessageBoxEx.Show(this, ex.Message, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                        }
                    });
                }, null);
            }
        }

        private void OnPeriodicityGetSetChange(object sender, EventArgs e)
        {
            if (!PeriodicityGetSet.IsSet)
            {
                Periodicity.SelectedIndex = 0;
                Periodicity.Text = "";
            }
            Periodicity.IsEnabled = PeriodicityGetSet.IsSet;
        }

        private void OnPeriodicityGetSetClick(object sender, EventArgs e)
        {
            var chartComponent = GetChartComponent();
            if (chartComponent == null) return;
            if (PeriodicityGetSet.IsSet) {
                var value = Periodicity.SelectedValue is ChartPeriodicity ? (int)Periodicity.SelectedValue : -1;
                if (value < 1 || value > 18)
                {
                    MessageBoxEx.Show(this, "Please select a valid periodicity value.");
                    return;
                }
                chartComponent.BeginSetPeriodicity((ChartPeriodicity)value, (AsyncCallback)delegate(IAsyncResult ar)
                {
                    Dispatcher.BeginInvoke((Action)delegate {
                        try {
                            chartComponent.EndSetPeriodicity(ar);
                        } catch (Exception ex) {
                            MessageBoxEx.Show(this, ex.Message, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                        }
                    });
                }, null);
            } else {
                chartComponent.BeginGetPeriodicity((AsyncCallback)delegate(IAsyncResult ar)
                {
                    Dispatcher.BeginInvoke((Action)delegate {
                        try {
                            Periodicity.SelectedValue = chartComponent.EndGetPeriodicity(ar);
                            PeriodicityGetSet.IsSet = true;
                        } catch (Exception ex) {
                            MessageBoxEx.Show(this, ex.Message, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                        }
                    });
                }, null);
            }
        }

        private void OnLinesGetSetChange(object sender, EventArgs e)
        {
            ChartPendingChanges(false);
            if (!LinesGetSet.IsSet)
                _lines.Clear();
            else {
                foreach (var line in _lines)
                    line.IsReadOnly = false;
            }
            AddLineButton.IsEnabled = LinesGetSet.IsSet;
            RemoveLineButton.IsEnabled = LinesGetSet.IsSet;
        }

        private void OnLinesGetSetClick(object sender, EventArgs e)
        {
            var chartComponent = GetChartComponent();
            if (chartComponent == null) return;
            if (LinesGetSet.IsSet) {
                chartComponent.BeginSetLines(_lines.Select(o => o.ChartLine), (AsyncCallback)delegate(IAsyncResult ar)
                {
                    Dispatcher.BeginInvoke((Action)delegate {
                        try {
                            chartComponent.EndSetLines(ar);
                            UpdateLines();
                            UpdatePrimarySecurity();
                        } catch (Exception ex) {
                            MessageBoxEx.Show(this, ex.Message, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                        }
                    });
                }, null);
            } else {
                UpdateLines();
            }
        }

        private void UpdateLines()
        {
            var chartComponent = GetChartComponent();
            if (chartComponent == null) return;
            chartComponent.BeginGetLines((AsyncCallback)delegate(IAsyncResult ar)
            {
                Dispatcher.BeginInvoke((Action)delegate {
                    try {
                        LinesGetSet.IsSet = true;
                        ProcessLines(chartComponent.EndGetLines(ar));
                    } catch (Exception ex) {
                        MessageBoxEx.Show(this, ex.Message, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    }
                });
            }, null);
        }

        private void ProcessLines(IList<ChartLine> lines)
        {
            _lines.Clear();
            foreach (var chartLine in lines)
                _lines.Add(new ChartLineViewModel(chartLine) { IsReadOnly = !LinesGetSet.IsSet });
            PropertyScrollViewer.ScrollToEnd();
            ChartPendingChanges(false);
            RemoveLineButton.IsEnabled = (Lines.SelectedItem is ChartLineViewModel && LinesGetSet.IsEnabled && LinesGetSet.IsSet);
            LinesGetSet.IsSet = true;
        }

        private void GetAllChartProperies()
        {
            var chartComponent = GetChartComponent();
            if (chartComponent == null) return;
            chartComponent.BeginGetProperties(new[] { "ChartId", "Shortcut", "PrimarySecurity", "Periodicity", "StartDate", "EndDate", "Lines" }, (AsyncCallback)delegate(IAsyncResult ar)
            {
                Dispatcher.BeginInvoke((Action)delegate
                {
                    try
                    {
                        var properties = chartComponent.EndGetProperties(ar);
                        if (properties.Count > 1 && properties[1].Name == "Shortcut")
                        {
                            Shortcut.Text = (string)properties[1].Value;
                            ShortcutGetSet.IsSet = true;
                        }
                        if (properties.Count > 2 && properties[2].Name == "PrimarySecurity")
                        {
                            PrimarySecurity.Text = (string)properties[2].Value;
                            PrimarySecurityGetSet.IsSet = true;
                        }
                        if (properties.Count > 3 && properties[3].Name == "Periodicity")
                        {
                            Periodicity.SelectedValue = (ChartPeriodicity)properties[3].Value;
                            PeriodicityGetSet.IsSet = true;
                        }
                        if (properties.Count > 4 && properties[4].Name == "StartDate")
                        {
                            StartDate.SelectedDate = ((DateTime)properties[4].Value).ToLocalTime();
                            StartDateGetSet.IsSet = true;
                        }
                        if (properties.Count > 5 && properties[5].Name == "EndDate")
                        {
                            EndDate.SelectedDate = ((DateTime)properties[5].Value).ToLocalTime();
                            EndDateGetSet.IsSet = true;
                        }
                        if (properties.Count > 6 && properties[6].Name == "Lines")
                        {
                            ProcessLines((IList<ChartLine>)properties[6].Value);
                            ChartPendingChanges(false);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBoxEx.Show(this, ex.Message, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    }
                });
            }, null);
        }

        private void OnSelectLine(object sender, RoutedEventArgs e)
        {
            var tbox = (TextBox)sender;
            var item = GetListViewItem<ChartLineViewModel>(Lines, tbox);
            if (item != null)
                Lines.SelectedItem = item;
        }

        private void OnLineChanged(object sender, TextChangedEventArgs e)
        {
            ChartPendingChanges(true);
        }
    }
}
